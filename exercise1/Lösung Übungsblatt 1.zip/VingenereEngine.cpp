#include "VingenereEngine.h"
#include <string.h>
#include <iostream>
#include <fstream>

VingenereEngine::VingenereEngine(void)
{
	this->cChiffre = NULL;
	this->cKlartext = NULL;
}

VingenereEngine::~VingenereEngine(void)
{
	if (this->cKlartext != NULL) delete this->cKlartext;
	if (this->cChiffre != NULL) delete this->cChiffre;
}

void VingenereEngine::SetKlartext(const char* cKlartext)
{
	if (this->cKlartext != NULL) delete this->cKlartext;
	this->cKlartext = new char[strlen(cKlartext)+1];
	strcpy(this->cKlartext,cKlartext);
}

void VingenereEngine::loadKlartext(const char* cFileName)
{
	if (this->cKlartext != NULL) delete this->cKlartext;
	std::fstream file(cFileName,std::ios::in);
	if (file.good())
	{
		file.seekg(0,std::ios::end);
		int size = file.tellg();
		file.seekg(0,std::ios::beg);
		
		this->cKlartext = new char[size+1];
		file.get(this->cKlartext,size+1);
	} else 
	{
		this->cKlartext = new char[1];
		this->cKlartext[0] = '\0';
	}
	file.close();
}

void VingenereEngine::printKlartext(void)
{
	std::cout << cKlartext << std::endl;
}

void VingenereEngine::saveKlartext(const char* cFileName)
{
	std::fstream file(cFileName,std::ios::out);
	file << this->cKlartext;
	file.close();
}

void VingenereEngine::SetChiffre(const char* cChiffre)
{
	if (this->cChiffre != NULL) delete this->cChiffre;
	this->cChiffre = new char[strlen(cChiffre)+1];
	strcpy(this->cChiffre,cChiffre);
}

void VingenereEngine::loadChiffre(const char* cFileName)
{
	if (this->cChiffre != NULL) delete this->cChiffre;
	std::fstream file(cFileName,std::ios::in);
	if (file.good())
	{
		file.seekg(0,std::ios::end);
		int size = file.tellg();
		file.seekg(0,std::ios::beg);
		
		this->cChiffre = new char[size+1];
		file.get(this->cChiffre,size+1);
	} else
	{
		this->cChiffre = new char[1];
		this->cChiffre[0] = '\0';
	}
	file.close();
}

void VingenereEngine::printChiffre(void)
{
	std::cout << cChiffre << std::endl;
}

void VingenereEngine::saveChiffre(const char* cFileName)
{
	std::fstream file(cFileName,std::ios::out);
	file << this->cChiffre;
	file.close();
}

void VingenereEngine::encode(const char *cPasswort)
{
	if (this->cKlartext == NULL) return;
	if (this->cChiffre != NULL) delete this->cChiffre;
	this->cChiffre = NULL;
	int size = strlen(this->cKlartext);
	this->cChiffre = new char[size+1];

	for (int i=0, p=0; this->cKlartext[i] != '\0'; i++)
	{
		if (this->cKlartext[i] == ' ')
		{
			this->cChiffre[i] = ' ';
		}
		else
		{
			if (((cPasswort[p]-'A') < 0 ) ||((cPasswort[p]-'A') > 25))
				std::cerr << "!!! FEHLER IM PASSWORT !!!" << std::endl;
			if (((this->cKlartext[i]-'a') < 0 ) ||((this->cKlartext[i]-'a') > 25))
				std::cerr << "!!! FEHLER IM KLARTEXT !!!" << std::endl;
			
			this->cChiffre[i] = 'A' + ((cPasswort[p]-'A') + (this->cKlartext[i]-'a'))%26;
			p++;
			if (cPasswort[p] == '\0')
				p = 0;
		}
	}
	this->cChiffre[size] = '\0';
}

void VingenereEngine::decode(const char *cPasswort)
{
	if (this->cChiffre == NULL) return;
	if (this->cKlartext != NULL) delete this->cKlartext;
	this->cKlartext = NULL;
	int size = strlen(this->cChiffre);
	this->cKlartext = new char[size+1];
	
	for (int i=0, p=0; this->cChiffre[i] != '\0'; i++)
	{
		if (this->cChiffre[i] == ' ')
		{
			this->cKlartext[i] = ' ';
		}
		else
		{
			if (((cPasswort[p]-'A') < 0 ) ||((cPasswort[p]-'A') > 25))
				std::cerr << "!!! FEHLER IM PASSWORT !!!" << std::endl;
			if (((this->cChiffre[i]-'A') < 0 ) ||((this->cChiffre[i]-'A') > 25))
				std::cerr << "!!! FEHLER IM CHIFFRE !!!" << std::endl;

			this->cKlartext[i] = 'a' + ((this->cChiffre[i]-'A') + 26 - (cPasswort[p]-'A'))%26;
			p++;
			if (cPasswort[p] == '\0')
				p = 0;
		}
	}
	this->cKlartext[size] = '\0';
}
