#ifndef VINGENERE_ENGINE_H
#define VINGENERE_ENGINE_H

class VingenereEngine
{
private:
	char *cKlartext;
	char *cChiffre;
public:
	VingenereEngine(void);
	~VingenereEngine(void);

	void SetKlartext(const char* cKlartext);
	void loadKlartext(const char* cFileName);
	void printKlartext(void);
	void saveKlartext(const char* cFileName);

	void SetChiffre(const char* cChiffre);
	void loadChiffre(const char* cFileName);
	void printChiffre(void);
	void saveChiffre(const char* cFileName);

	void encode(const char *cPasswort);
	void decode(const char *cPasswort);
};

#endif //VINGENERE_ENGINE_H