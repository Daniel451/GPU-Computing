#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <string>
#include "VingenereEngine.h"

using namespace std;

void wait()
{
	cout << endl << "--> Press Enter to Continue <--" << endl << endl;
	cin.clear();
	cin.ignore(cin.rdbuf()->in_avail());
	cin.get();;
}

int main()
{
	while (true)
	{
		char com;
		cout << "Bitte Kommando eingeben (v,e,q):";
		cin >> com;

		if (com == 'q')
			break;

		if (com == 'e' || com == 'v')
		{
			string sFileName;
			string sPasswort;
			
			cout << "Bitte geben Sie den Namen der Datei, die sie ";
			cout << (com == 'e' ? "entschluessen" : "verschluesseln");
			cout << " wollen ein:   ";
			cin >> sFileName;

			cout << "Bitte geben Sie Ihr Passwort ein:  ";
			cin >> sPasswort;

			VingenereEngine vEngine;
			
			if (com == 'e')
			{
				vEngine.loadChiffre(sFileName.c_str());
				vEngine.printChiffre();
				vEngine.decode(sPasswort.c_str());
				vEngine.printKlartext();
			}
			else
			{
				string sOutFileName = sFileName + ".enc";
				vEngine.loadKlartext(sFileName.c_str());
				vEngine.printKlartext();
				vEngine.encode(sPasswort.c_str());
				vEngine.printChiffre();
				vEngine.saveChiffre(sOutFileName.c_str());
			}

		}
	}
}
